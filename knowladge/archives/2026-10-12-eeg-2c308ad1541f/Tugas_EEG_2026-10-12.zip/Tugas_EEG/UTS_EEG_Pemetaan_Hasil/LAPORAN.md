# Pemetaan EEG ke perkiraan tangan

Memproses 6 rekaman, 2 subjek, 119,040 sampel waktu, dan 64 kanal EEG per sampel.

Data R04/R08/R12 merekam **imajinasi gerakan** tangan. T0 berarti istirahat, T1 instruksi tangan kiri, T2 instruksi tangan kanan. Instruksi bukan bukti bahwa subjek melakukan gerakan atau membayangkan dengan benar. Tidak ada koordinat/sudut jari dalam data.

## Hasil pengujian

| Pengujian | Benar / jumlah | Akurasi | Balanced accuracy | Pembanding mayoritas |
|---|---:|---:|---:|---:|
| Trial 3 kelas: rest/kiri/kanan | 70/174 | 40.23% | 39.48% | 48.28% |
| Trial 2 kelas: kiri/kanan, hanya interval tugas | 54/90 | 60.00% | 60.08% | 51.11% |
| Jendela berjalan 3 kelas | 486/1164 | 41.75% | 41.39% | 48.97% |

**Akurasi kiri/kanan dihitung dengan model dua kelas tersendiri ketika interval tugas sudah diketahui dari eksperimen. Angka itu tidak mengukur kemampuan mendeteksi istirahat dan bukan akurasi skeleton sepanjang waktu.** Skeleton memakai model tiga kelas.

Model tiga kelas harus dibandingkan dengan tebakan yang selalu memilih kelas terbanyak (rest). Jika hasil lebih rendah, model belum menunjukkan manfaat sebagai pengendali. Alur ini berguna untuk belajar pemrosesan yang dapat diuji, termasuk kegagalannya.

Balanced accuracy adalah rata-rata recall tiap kelas sehingga kelas rest yang lebih banyak tidak mendominasi angka.

## Kalibrasi dan pengujian

- Untuk setiap run uji, kalibrasi LDA memakai dua run lain dari subjek yang sama. Tidak ada pembagian acak jendela dari satu run ke train/test.
- Pita, jendela, dan shrinkage ditetapkan; tidak dioptimalkan menggunakan akurasi run uji.
- Baseline daya memakai instruksi rest awal 1–3,5 s pada masing-masing run. Sampel 0–1 s tidak masuk baseline karena transien filter.
- CSV menyimpan 180 segmen. 6 segmen rest awal dipakai baseline dan dikeluarkan dari penilaian maupun kalibrasi kelas.
- Fitur trial memakai onset+1 sampai onset+3,5 s; ujung interval tidak disertakan.
- Prediksi berjalan memakai 2,5 s sebelumnya, diperbarui setiap 0,25 s. Prediksi tetap berjalan melewati transisi; skor hanya memakai jendela yang seluruhnya di dalam satu interval selain rest awal.
- Dari 2898 jendela, 1734 dikeluarkan dari skor karena transisi, baseline, atau area tanpa anotasi. Jendela saling tumpang tindih sehingga bukan ribuan percobaan independen.
- Pemrosesan sinyal kausal per run. Kalibrasi kelas offline memakai run lain, yang mungkin direkam sesudah run uji; ini belum pengujian sistem langsung yang dikalibrasi hanya dari masa lalu.

| Run uji | Run kalibrasi | Akurasi 3 kelas | Akurasi kiri/kanan saja |
|---|---|---:|---:|
| S001R04 | S001R08, S001R12 | 41.38% | 73.33% |
| S001R08 | S001R04, S001R12 | 51.72% | 53.33% |
| S001R12 | S001R04, S001R08 | 55.17% | 80.00% |
| S002R04 | S002R08, S002R12 | 41.38% | 60.00% |
| S002R08 | S002R04, S002R12 | 24.14% | 46.67% |
| S002R12 | S002R04, S002R08 | 27.59% | 46.67% |

## Letak Transformasi-Z dalam program

Alur: amplitudo EEG x[n] → referensi rata-rata 64 kanal → filter IIR mu/beta y[n] → daya C3/C4 → perubahan daya terhadap rest → LDA → kelas perkiraan → skeleton ilustratif.

Transformasi-Z mendeskripsikan hubungan masukan dan keluaran filter, Y(z)=H(z)X(z). Program tidak perlu menghitung X(z) untuk semua titik z. Filter dijalankan lewat persamaan beda, sebagai bentuk praktis H(z).

Setiap pita memakai Butterworth orde 4 dari dua bagian orde 2:

    H(z) = produk_k (b0_k+b1_k z^-1+b2_k z^-2) / (1+a1_k z^-1+a2_k z^-2)
    y[n] = b0 x[n]+b1 x[n-1]+b2 x[n-2]-a1 y[n-1]-a2 y[n-2]

Kondisi awal nol. Keluaran bagian pertama masuk ke bagian kedua. Pole berada di |z|<1; tidak memakai filtfilt.

**mu: 8–13 Hz, fs=160 Hz**

| Bagian | b0 | b1 | b2 | a0 | a1 | a2 |
|---|---:|---:|---:|---:|---:|---:|
| 1 | 0.00844269293 | 0.0168853859 | 0.00844269293 | 1 | -1.64361878 | 0.850702967 |
| 2 | 1 | -2 | 1 | 1 | -1.78456776 | 0.890495242 |

**beta: 13–30 Hz, fs=160 Hz**

| Bagian | b0 | b1 | b2 | a0 | a1 | a2 |
|---|---:|---:|---:|---:|---:|---:|
| 1 | 0.0746585812 | 0.149317162 | 0.0746585812 | 1 | -0.739217625 | 0.556317853 |
| 2 | 1 | -2 | 1 | 1 | -1.43492482 | 0.702920814 |

Persamaan beda manual dicek terhadap scipy.signal.sosfilt pada 10 s pertama semua 64 kanal tiap run. Selisih maksimum: 1.6e-13 uV.

P = rata-rata y[n]^2 (uV²). Empat fitur adalah 10 log10(P/P0) dalam dB untuk mu C3, mu C4, beta C3, beta C4. Negatif menunjukkan penurunan daya terhadap rest, bukan langsung jumlah tekukan jari.

LDA mempelajari pola empat fitur dari trial kalibrasi berlabel, dengan shrinkage kovarians 0,5 dan prior kelas sama. Ini klasifikasi statistik terawasi yang terpisah dari T-Z. Skor terbesar memilih kelas; skor relatif bukan probabilitas yang telah dikalibrasi.

## Membaca output

- trial_dan_prediksi.csv: fitur, instruksi, run kalibrasi, prediksi tiga kelas dan dua kelas khusus tugas. evaluation_eligible=False pada rest awal.
- prediksi_semua_rekaman.csv: waktu jendela, fitur, prediksi kausal semua run; label pembanding ditambahkan sesudah inferensi. end_s adalah waktu keputusan tersedia. evaluation_label dipakai menghitung skor.
- SxxxRxx_sinyal_filter.csv: C3/C4 asli, setelah referensi, dan hasil filter. Semua 64 kanal diproses; amplitudo output disimpan untuk C3/C4.
- evaluasi.json: angka penuh, confusion matrix, pembagian run, batas interpretasi, dan hash input.
- filter_TZ.json dan filter_TZ.png: koefisien H(z), respons frekuensi dan pole.
- model_kalibrasi.json: bobot model per run.
- confusion_matrix.png: baris instruksi, kolom prediksi.

Skeleton menekuk tangan yang diperkirakan aktif dengan pose buatan yang sama setiap kali. Bentuk jari, besar tekukan, dan kecepatan gerak tidak direkonstruksi dari EEG.

## Sumber

- [PhysioNet EEG Motor Movement/Imagery Dataset](https://physionet.org/content/eegmmidb/1.0.0/)
- [MNE: pemetaan run](https://mne.tools/stable/generated/mne.datasets.eegbci.load_data.html)
- [SciPy Butterworth](https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.butter.html)
- [SciPy SOS kausal](https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.sosfilt.html)
- [LDA dan shrinkage](https://scikit-learn.org/stable/modules/lda_qda.html)
