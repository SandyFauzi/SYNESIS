import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';

const root = path.resolve(process.argv[2] || '.');
const files = ['S001R04.edf','S001R08.edf','S001R12.edf','S002R04.edf','S002R08.edf','S002R12.edf'];
const output = path.join(root, 'CSV_EEG');
const checksumText = await fs.readFile(path.join(root, 'PhysioNet_SHA256SUMS.txt'), 'utf8');
const hashes = new Map(checksumText.trim().split(/\r?\n/).map(line => {
  const match = line.match(/^([a-f0-9]{64})\s+\*?(.+)$/);
  if (!match) throw new Error('Invalid checksum line');
  return [match[2].replace(/^\.\//,''), match[1]];
}));
const csvCell = value => {
  const s = value === null || value === undefined ? '' : String(value);
  return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g,'""') + '"' : s;
};
const csvRow = values => values.map(csvCell).join(',');
const activities = {T0:'Istirahat', T1:'Imajinasi tangan kiri', T2:'Imajinasi tangan kanan'};

function readEDF(data, filename) {
  const ascii = (offset,length) => data.subarray(offset,offset+length).toString('ascii').trim();
  if (ascii(0,8) !== '0' || !ascii(192,44).startsWith('EDF+C')) throw new Error('Expected continuous EDF+');
  const headerBytes=Number(ascii(184,8)), recordCount=Number(ascii(236,8));
  const recordDuration=Number(ascii(244,8)), signalCount=Number(ascii(252,4));
  if(headerBytes !== 256*(signalCount+1) || !Number.isInteger(recordCount) || recordCount<1 || !(recordDuration>0)) throw new Error('Invalid EDF header');
  let pos=256;
  const header={};
  for (const [name,width] of [['label',16],['transducer',80],['unit',8],['physicalMin',8],['physicalMax',8],['digitalMin',8],['digitalMax',8],['prefilter',80],['samplesPerRecord',8],['reserved',32]]) {
    header[name]=Array.from({length:signalCount},(_,i)=>ascii(pos+i*width,width));
    pos+=signalCount*width;
  }
  const samples=header.samplesPerRecord.map(Number);
  const offsets=[]; let recordBytes=0;
  for(const n of samples){if(!Number.isInteger(n)||n<1)throw new Error('Invalid sample count');offsets.push(recordBytes);recordBytes+=2*n;}
  if(data.length !== headerBytes+recordCount*recordBytes)throw new Error('Truncated or unexpected EDF size: '+filename);
  const annIndexes=header.label.map((s,i)=>s==='EDF Annotations'?i:-1).filter(i=>i>=0);
  if(annIndexes.length!==1)throw new Error('Expected one annotation channel');
  const ai=annIndexes[0];
  const channels=header.label.map((s,i)=>i).filter(i=>i!==ai);
  const rate=samples[channels[0]]/recordDuration;
  if(channels.length!==64 || rate!==160 || channels.some(i=>samples[i]!==samples[channels[0]]))throw new Error('Unexpected EEG montage or sample rates');
  const totalSamples=recordCount*samples[channels[0]];
  const channelMetadata=channels.map(i=>{
    const unit=header.unit[i];
    const multiplier=({uV:1,V:1e6,mV:1e3})[unit];
    if(!multiplier)throw new Error('Unsupported amplitude unit: '+unit);
    const physicalMin=Number(header.physicalMin[i]), physicalMax=Number(header.physicalMax[i]);
    const digitalMin=Number(header.digitalMin[i]), digitalMax=Number(header.digitalMax[i]);
    const scale=(physicalMax-physicalMin)/(digitalMax-digitalMin);
    if(![physicalMin,physicalMax,digitalMin,digitalMax,scale].every(Number.isFinite)||scale===0)throw new Error('Invalid calibration');
    return {edfIndex:i,originalLabel:header.label[i],csvColumn:header.label[i].replace(/\.+$/,'')+'_uV',originalUnit:unit,outputUnit:'uV',physicalMin,physicalMax,digitalMin,digitalMax,scale,multiplier,prefilter:header.prefilter[i]};
  });
  if(new Set(channelMetadata.map(c=>c.csvColumn)).size!==channels.length)throw new Error('Duplicate CSV channel names');
  const annotations=[];
  for(let r=0;r<recordCount;r++){
    const start=headerBytes+r*recordBytes+offsets[ai];
    const tals=data.subarray(start,start+2*samples[ai]).toString('utf8').split('\0').filter(Boolean);
    if(!tals.length || Math.abs(Number(tals[0].split('\x14')[0].split('\x15')[0])-r*recordDuration)>1e-8)throw new Error('Non-continuous recording time');
    for(const tal of tals){
      const parts=tal.split('\x14'), timing=parts[0].split('\x15');
      for(const label of parts.slice(1).filter(Boolean)){
        if(!Object.hasOwn(activities,label)||timing[1]===undefined)throw new Error('Unsupported annotation: '+label);
        const onset=Number(timing[0]), duration=Number(timing[1]);
        if(!Number.isFinite(onset)||!Number.isFinite(duration)||duration<0)throw new Error('Invalid annotation timing');
        annotations.push({onset,duration,label,activity:activities[label],startSample:Math.round(onset*rate),endSample:Math.round((onset+duration)*rate)});
      }
    }
  }
  annotations.sort((a,b)=>a.onset-b.onset);
  for(let i=0;i<annotations.length;i++)if(annotations[i].startSample<0 || annotations[i].endSample>totalSamples || (i&&annotations[i].startSample<annotations[i-1].endSample))throw new Error('Overlapping/out-of-range annotations');
  const digitalAt=(sample,c)=>{
    const r=Math.floor(sample/samples[c.edfIndex]), within=sample%samples[c.edfIndex];
    return data.readInt16LE(headerBytes+r*recordBytes+offsets[c.edfIndex]+within*2);
  };
  const valueAt=(sample,c)=>(c.physicalMin+(digitalAt(sample,c)-c.digitalMin)*c.scale)*c.multiplier;
  return {rate,totalSamples,recordCount,recordDuration,duration:recordCount*recordDuration,channelMetadata,annotations,digitalAt,valueAt,startDate:ascii(168,8),startTime:ascii(176,8)};
}

const parsed=[];
for(const filename of files){
  const data=await fs.readFile(path.join(root,filename));
  const hash=crypto.createHash('sha256').update(data).digest('hex');
  const relative=filename.slice(0,4)+'/'+filename;
  if(hash!==hashes.get(relative))throw new Error('Checksum does not match PhysioNet: '+filename);
  parsed.push({filename,hash,bytes:data.length,sourceUrl:'https://physionet.org/files/eegmmidb/1.0.0/'+relative,...readEDF(data,filename)});
}
await fs.mkdir(output,{recursive:true});
const manifest=[['file','subject','run','sampling_rate_Hz','eeg_channels','sample_rows','duration_s','T0_events','T1_events','T2_events','signals_csv','annotations_csv','source_url','sha256']];
const metadata=[];
for(const p of parsed){
  const stem=p.filename.replace(/\.edf$/,''), signalName=stem+'.csv', annotationName=stem+'_annotations.csv';
  const headers=['time_s','annotation',...p.channelMetadata.map(c=>c.csvColumn)];
  const rows=[csvRow(headers)];
  let annIndex=0;
  for(let sample=0;sample<p.totalSamples;sample++){
    while(annIndex<p.annotations.length && sample>=p.annotations[annIndex].endSample)annIndex++;
    const ann=p.annotations[annIndex];
    const label=ann && sample>=ann.startSample && sample<ann.endSample ? ann.label : '';
    const values=p.channelMetadata.map(c=>p.valueAt(sample,c));
    if(values.some(v=>!Number.isFinite(v)))throw new Error('Non-finite sample');
    rows.push(csvRow([sample/p.rate,label,...values]));
  }
  await fs.writeFile(path.join(output,signalName),rows.join('\r\n')+'\r\n');
  const annotationRows=[['event_index','onset_s','duration_s','end_s','label','activity'],...p.annotations.map((a,i)=>[i,a.onset,a.duration,Number((a.onset+a.duration).toFixed(8)),a.label,a.activity])];
  await fs.writeFile(path.join(output,annotationName),annotationRows.map(csvRow).join('\r\n')+'\r\n');
  const saved=(await fs.readFile(path.join(output,signalName),'utf8')).trimEnd().split(/\r?\n/);
  if(saved.length!==p.totalSamples+1 || saved[0]!==csvRow(headers))throw new Error('CSV row/header mismatch');
  let maxDigitalError=0, blanks=0;
  for(let sample=0;sample<p.totalSamples;sample++){
    const values=saved[sample+1].split(',');
    if(values.length!==headers.length || Number(values[0])!==sample/p.rate)throw new Error('CSV shape/time mismatch');
    if(!values[1])blanks++;
    for(let c=0;c<p.channelMetadata.length;c++){
      const ch=p.channelMetadata[c], physical=Number(values[c+2]);
      const recovered=(physical/ch.multiplier-ch.physicalMin)/ch.scale+ch.digitalMin;
      maxDigitalError=Math.max(maxDigitalError,Math.abs(recovered-p.digitalAt(sample,ch)));
    }
  }
  if(maxDigitalError>1e-6)throw new Error('CSV amplitude round-trip mismatch');
  const savedAnn=(await fs.readFile(path.join(output,annotationName),'utf8')).trimEnd().split(/\r?\n/);
  if(savedAnn.length!==annotationRows.length || savedAnn.some((line,i)=>line!==csvRow(annotationRows[i])))throw new Error('Annotation CSV mismatch');
  const counts={T0:0,T1:0,T2:0};for(const a of p.annotations)counts[a.label]++;
  manifest.push([p.filename,p.filename.slice(0,4),p.filename.slice(4,7),p.rate,p.channelMetadata.length,p.totalSamples,p.duration,counts.T0,counts.T1,counts.T2,signalName,annotationName,p.sourceUrl,p.hash]);
  metadata.push({file:p.filename,sourceUrl:p.sourceUrl,sha256:p.hash,checksumVerified:true,sourceBytes:p.bytes,rate_Hz:p.rate,samples:p.totalSamples,duration_s:p.duration,startDateEDF:p.startDate,startTimeEDF:p.startTime,units:'uV',channels:p.channelMetadata,annotationCounts:counts,unannotatedSamples:blanks,maximumDigitalRoundTripError:maxDigitalError});
  console.log(JSON.stringify({file:p.filename,rows:p.totalSamples,channels:p.channelMetadata.length,duration_s:p.duration,counts,unannotatedSamples:blanks,maxDigitalError}));
}
await fs.writeFile(path.join(output,'manifest.csv'),manifest.map(csvRow).join('\r\n')+'\r\n');
await fs.writeFile(path.join(output,'metadata.json'),JSON.stringify(metadata,null,2)+'\n');
const totalSamples=metadata.reduce((s,m)=>s+m.samples,0);
const totalTrials=metadata.reduce((s,m)=>s+m.annotationCounts.T1+m.annotationCounts.T2,0);
const readme=[
 '# Data EEG dalam CSV',
 '',
 'Sumber: PhysioNet EEG Motor Movement/Imagery Dataset versi 1.0.0.',
 'https://physionet.org/content/eegmmidb/1.0.0/',
 'Schalk, G. (2009). DOI: https://doi.org/10.13026/C28G6P',
 '',
 'Data terdiri dari subjek S001 dan S002, masing-masing run R04, R08, R12.',
 'Ketiga run menggunakan tugas imajinasi gerakan tangan kiri/kanan:',
 'https://mne.tools/stable/generated/mne.datasets.eegbci.load_data.html',
 'Dua rekaman awal dipertahankan dan empat rekaman tambahan diunduh dari PhysioNet.',
 'Semua enam EDF cocok dengan SHA-256 resmi dalam PhysioNet_SHA256SUMS.txt.',
 '',
 'Total: '+totalSamples+' baris sampel EEG dan '+totalTrials+' trial T1/T2.',
 '',
 'Setiap CSV sinyal berisi time_s (detik sejak awal rekaman), annotation (T0/T1/T2), dan 64 kanal EEG dalam mikrovolt (uV).',
 'Satu baris adalah satu waktu pengambilan sampel. Frekuensi sampling 160 Hz, sehingga jarak waktu antarbaris 0.00625 detik.',
 'Sinyal dipertahankan tanpa filter, penghalusan, interpolasi, atau penghilangan artefak.',
 'Kalibrasi digital-ke-fisik mengikuti physical/digital min/max pada header EDF. metadata.json menyimpan parameter dan nama kanal asli.',
 'Titik di akhir nama kanal EDF dihapus untuk header CSV: C3.. menjadi C3_uV.',
 '',
 'Setiap *_annotations.csv menyimpan indeks anotasi (mulai 0), onset, durasi, waktu akhir, label, dan nama aktivitas.',
 'T0 = istirahat; T1 = imajinasi tangan kiri; T2 = imajinasi tangan kanan. Pemetaan ini khusus run R04/R08/R12.',
 'Interval anotasi memakai onset inklusif dan akhir eksklusif. annotation kosong berarti waktu tersebut tidak memiliki anotasi EDF; tidak otomatis diberi T0.',
 'manifest.csv memuat ringkasan, URL asal, checksum, dan nama CSV setiap rekaman.',
 'CSV menggunakan koma sebagai pemisah dan titik sebagai tanda desimal. Di Excel, gunakan Data > From Text/CSV bila kolom tidak terpisah otomatis.',
 '',
 'Notebook lama masih menetapkan dua file awal di EDF_FILES. Untuk menggunakan keenam rekaman, ganti baris tersebut menjadi:',
 'EDF_FILES = sorted(DATA_DIR.glob("S00[12]R[0-9][0-9].edf"))',
 'Folder ini hanya menambahkan run R04/R08/R12. Jika nanti menambahkan jenis run lain, sesuaikan pemetaan label terlebih dahulu.',
 'Ringkasan notebook lama menggabungkan trial; bila membandingkan subjek, pertahankan identitas subjek dalam analisis.',
 ''
].join('\n');
await fs.writeFile(path.join(output,'README.md'),readme);
console.log(JSON.stringify({output,recordings:metadata.length,totalSamples,totalTrials,csvFiles:13}));
