"""Visualisasi ilustratif EEG dengan kerangka tangan 2D untuk proyek UTS.

Jalankan:
    python UTS_EEG_Skeleton_Tangan.py
Rekaman lain:
    python UTS_EEG_Skeleton_Tangan.py --file CSV_EEG/S002R08.csv
Simpan gambar pada detik 5:
    python UTS_EEG_Skeleton_Tangan.py --time 5 --preview tangan.png

Alur: CSV -> EEG C3 -> filter rata-rata 3 sampel -> tekukan jari.
H(z) = (1 + z^-1 + z^-2) / 3
T1/T2 dari anotasi menentukan tangan kiri/kanan yang aktif.
Besar |EEG terfilter| menentukan tekukan ilustratif, bukan posisi jari terukur.
Pustaka: python -m pip install numpy pandas matplotlib
"""

import argparse
import re
import time
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib

# Mode preview dapat berjalan tanpa membuka jendela.
import sys
if '--preview' in sys.argv:
    matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib.widgets import Button, Slider

ROOT = Path(__file__).resolve().parent
DEFAULT_CSV = ROOT / 'CSV_EEG' / 'S001R04.csv'
FPS = 20
COLORS = {'left': '#2874A6', 'right': '#D46B29', 'rest': '#AAB2BD'}


def load_eeg(csv_path):
    """Baca satu kanal dan terapkan persamaan beda secara manual."""
    if not re.fullmatch(r'S\d{3}R(?:04|08|12)', csv_path.stem):
        raise ValueError('Gunakan CSV sinyal run R04, R08, atau R12.')
    data = pd.read_csv(csv_path)
    t = data['time_s'].to_numpy(dtype=float)
    x = data['C3_uV'].to_numpy(dtype=float)
    labels = data['annotation'].fillna('').astype(str).to_numpy()
    if len(t) < 3 or not np.isfinite(t).all() or not np.isfinite(x).all():
        raise ValueError('Data waktu/amplitudo harus valid dan minimal 3 sampel.')
    if not np.all(np.diff(t) > 0) or not np.isin(labels, ['', 'T0', 'T1', 'T2']).all():
        raise ValueError('Waktu harus berurutan; label harus T0, T1, T2, atau kosong.')

    # y[n] = (x[n] + x[n-1] + x[n-2]) / 3; sampel sebelumnya nol.
    y = np.zeros(len(x))
    for n in range(len(x)):
        total = x[n]
        if n >= 1:
            total += x[n - 1]
        if n >= 2:
            total += x[n - 2]
        y[n] = total / 3
    return t, x, y, labels


# Satu pergelangan + 5 jari x 4 titik = 21 titik kerangka.
# Titik adalah gambar 2D buatan untuk ilustrasi, bukan hasil pengukuran.
OPEN_HAND = np.array([
    [0, 0],
    [-.30, .42], [-.70, .72], [-1.04, 1.03], [-1.30, 1.30],
    [-.45, 1.10], [-.50, 1.85], [-.54, 2.45], [-.56, 2.85],
    [0, 1.20], [0, 2.05], [0, 2.70], [0, 3.10],
    [.45, 1.13], [.52, 1.86], [.57, 2.43], [.60, 2.82],
    [.83, .98], [1, 1.55], [1.12, 2.03], [1.20, 2.35],
], dtype=float)
CLOSED_HAND = np.array([
    [0, 0],
    [-.30, .42], [-.62, .78], [-.45, 1.15], [.16, 1.05],
    [-.45, 1.10], [-.60, 1.53], [-.64, 1.10], [-.45, .88],
    [0, 1.20], [0, 1.70], [0, 1.16], [.03, .89],
    [.45, 1.13], [.57, 1.59], [.60, 1.10], [.46, .87],
    [.83, .98], [1.02, 1.29], [1.06, .94], [.85, .77],
], dtype=float)
BONES = []
for base in [1, 5, 9, 13, 17]:
    BONES.extend([(0, base), (base, base+1), (base+1, base+2), (base+2, base+3)])
BONES.extend([(1, 5), (5, 9), (9, 13), (13, 17)])


def hand_points(bend, mirror=1):
    """bend 0 = terbuka; bend 1 = menekuk penuh secara ilustratif."""
    points = (1-bend) * OPEN_HAND + bend * CLOSED_HAND
    points[:, 0] *= mirror
    return points


def visual_state(y, labels, index, amplitude_reference):
    """Pemetaan visual yang sengaja sederhana, bukan klasifikasi EEG."""
    strength = float(np.clip(abs(y[index]) / amplitude_reference, 0, 1))
    label = labels[index]
    left_bend = strength if label == 'T1' else .15
    right_bend = strength if label == 'T2' else .15
    return label, strength, left_bend, right_bend


def make_view(t, x, y, labels, filename):
    fig = plt.figure(figsize=(12, 8))
    fig.suptitle('Visualisasi EEG dengan kerangka tangan', fontsize=18, y=.97)
    fig.text(.5, .92, r'Filter: $H(z)=(1+z^{-1}+z^{-2})/3$   |   Kanal C3   |   '+filename,
             ha='center', fontsize=11)
    status = fig.text(.5, .87, '', ha='center', fontsize=12)
    grid = fig.add_gridspec(2, 2, height_ratios=[1.55, 1], left=.08, right=.96,
                           bottom=.20, top=.81, hspace=.35)
    hand_axes = [fig.add_subplot(grid[0, 0]), fig.add_subplot(grid[0, 1])]
    hand_artists = []
    for ax in hand_axes:
        ax.set(xlim=(-1.6, 1.6), ylim=(-.25, 3.35), aspect='equal')
        ax.axis('off')
        bones, = ax.plot([], [], linewidth=2.5)
        joints = ax.scatter([], [], s=32, zorder=3)
        hand_artists.append((bones, joints))

    eeg_ax = fig.add_subplot(grid[1, :])
    raw_line, = eeg_ax.plot([], [], color='#9AA4AF', linewidth=.9, label='EEG asli')
    filtered_line, = eeg_ax.plot([], [], color='#2874A6', linewidth=1.3, label='EEG setelah filter')
    cursor = eeg_ax.axvline(0, color='#D46B29', linewidth=1.5)
    span = max(float(np.ptp(x)), 1.0)
    eeg_ax.set_ylim(float(x.min())-.1*span, float(x.max())+.1*span)
    eeg_ax.set(xlabel='Waktu (detik)', ylabel='Amplitudo (uV)')
    eeg_ax.grid(alpha=.2)
    eeg_ax.legend(loc='upper right', fontsize=9)
    fig.text(.08, .055, 'Spasi: jeda/putar. Panah kiri/kanan: geser 1 detik. R: kembali ke awal.', fontsize=9)
    fig.text(.08, .025, 'Ilustrasi: label menentukan tangan; amplitudo EEG menentukan tekukan. Posisi jari tidak diukur.', fontsize=9)

    # Skala hanya untuk tampilan: persentil ke-95 |y| = tekukan maksimal.
    reference = max(float(np.percentile(np.abs(y), 95)), 1e-9)
    activity = {'T0': 'Istirahat', 'T1': 'Imajinasi tangan kiri',
                'T2': 'Imajinasi tangan kanan', '': 'Tanpa anotasi'}

    def draw_at(seconds):
        seconds = float(np.clip(seconds, t[0], t[-1]))
        index = max(0, int(np.searchsorted(t, seconds, side='right')-1))
        label, strength, left_bend, right_bend = visual_state(y, labels, index, reference)
        status.set_text(f'{seconds:.2f} s | {label or "kosong"}: {activity[label]} | EEG filter: {y[index]:.2f} uV')
        for j, (side, bend, active_label, mirror) in enumerate([
            ('left', left_bend, 'T1', -1), ('right', right_bend, 'T2', 1)
        ]):
            active = label == active_label
            color = COLORS[side] if active else COLORS['rest']
            points = hand_points(bend, mirror)
            # NaN memisahkan ruas tulang agar tidak tersambung secara acak.
            segments = np.array([[points[a], points[b], [np.nan, np.nan]] for a, b in BONES]).reshape(-1, 2)
            bones, joints = hand_artists[j]
            bones.set_data(segments[:, 0], segments[:, 1])
            bones.set_color(color)
            joints.set_offsets(points)
            joints.set_color(color)
            name = 'Tangan kiri' if side == 'left' else 'Tangan kanan'
            detail = f'Aktif | tekukan ilustrasi {strength:.0%}' if active else 'Posisi netral'
            hand_axes[j].set_title(name+'\n'+detail, color=color, fontsize=12, pad=10)
        start = max(float(t[0]), min(seconds-2, float(t[-1])-6))
        end = min(float(t[-1]), start+6)
        selected = (t >= start) & (t <= end)
        raw_line.set_data(t[selected], x[selected])
        filtered_line.set_data(t[selected], y[selected])
        cursor.set_xdata([seconds, seconds])
        eeg_ax.set_xlim(start, end)
        return label, left_bend, right_bend

    return fig, draw_at


def play(fig, draw_at, t, start):
    """Kontrol animasi. Waktu memakai jam agar sesuai durasi rekaman."""
    state = {'playing': True, 'position': start, 'origin': time.perf_counter()-start}
    button = Button(fig.add_axes([.08, .105, .08, .045]), 'Jeda')
    slider = Slider(fig.add_axes([.24, .11, .65, .03]), 'Waktu',
                    valmin=float(t[0]), valmax=float(t[-1]), valinit=start, valfmt='%.2f s')

    def seek(value):
        state['position'] = float(value)
        state['origin'] = time.perf_counter()-state['position']
        draw_at(state['position'])
        fig.canvas.draw_idle()

    def toggle(event=None):
        state['playing'] = not state['playing']
        state['origin'] = time.perf_counter()-state['position']
        button.label.set_text('Jeda' if state['playing'] else 'Putar')
        fig.canvas.draw_idle()

    def keypress(event):
        if event.key == ' ':
            toggle()
        elif event.key in ['left', 'right', 'r']:
            value = 0 if event.key == 'r' else state['position']+(-1 if event.key == 'left' else 1)
            slider.set_val(float(np.clip(value, t[0], t[-1])))

    def tick(frame):
        if state['playing']:
            state['position'] = min(time.perf_counter()-state['origin'], float(t[-1]))
            if state['position'] >= t[-1]:
                state['playing'] = False
                button.label.set_text('Putar')
            # Pembaruan slider dari animasi tidak memanggil seek lagi.
            slider.eventson = False
            slider.drawon = False
            slider.set_val(state['position'])
            slider.eventson = True
            slider.drawon = True
            draw_at(state['position'])
        return ()

    slider.on_changed(seek)
    button.on_clicked(toggle)
    fig.canvas.mpl_connect('key_press_event', keypress)
    animation = FuncAnimation(fig, tick, interval=1000/FPS, cache_frame_data=False)
    # Simpan referensi agar tombol, slider, dan animasi tetap hidup.
    fig.eeg_controls = (animation, slider, button)
    return animation


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--file', type=Path, default=DEFAULT_CSV, help='CSV sinyal R04/R08/R12')
    parser.add_argument('--time', type=float, default=0, help='Mulai pada detik ini')
    parser.add_argument('--preview', type=Path, help='Simpan gambar PNG tanpa membuka jendela')
    args = parser.parse_args()
    try:
        t, x, y, labels = load_eeg(args.file)
    except (OSError, ValueError, KeyError) as error:
        parser.error(str(error))
    if not np.isfinite(args.time):
        parser.error('--time harus berupa angka terbatas.')
    start = float(np.clip(args.time, t[0], t[-1]))
    fig, draw_at = make_view(t, x, y, labels, args.file.name)
    draw_at(start)
    print('Label dari anotasi; tekukan jari adalah visualisasi ilustratif amplitudo EEG.')
    if args.preview:
        fig.savefig(args.preview, dpi=150)
        plt.close(fig)
        print('Gambar tersimpan:', args.preview)
    else:
        animation = play(fig, draw_at, t, start)
        plt.show()


if __name__ == '__main__':
    main()
