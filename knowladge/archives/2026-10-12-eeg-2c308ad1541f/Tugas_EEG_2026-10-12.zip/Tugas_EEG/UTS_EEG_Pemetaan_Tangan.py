"""Pemetaan imajinasi tangan dari seluruh CSV EEG R04/R08/R12.

Jalankan dari folder ini:
    python UTS_EEG_Pemetaan_Tangan.py

Tanpa membuka jendela (analisis tetap memproses semua run):
    python UTS_EEG_Pemetaan_Tangan.py --no-gui --time 7

Pilih rekaman yang ditampilkan:
    python UTS_EEG_Pemetaan_Tangan.py --record S002R08

T-Z -> filter mu/beta -> daya C3/C4 -> kalibrasi statistik LDA -> prediksi.
Skeleton mengikuti prediksi tiga kelas, bukan anotasi asli.
Posisi jari adalah ilustrasi; dataset tidak memiliki data sudut jari.

Pustaka: python -m pip install numpy scipy pandas matplotlib
Simpan eeg_motor_analysis.py dan eeg_motor_view.py di folder yang sama.
"""
import argparse
from pathlib import Path

import numpy as np
import matplotlib

from eeg_motor_analysis import analyze_all, save_outputs, write_report

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--data-dir", type=Path, default=ROOT / "CSV_EEG")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "UTS_EEG_Pemetaan_Hasil")
    parser.add_argument("--record", default="S001R04", help="Nama run untuk tampilan, tanpa .csv")
    parser.add_argument("--time", type=float, default=0, help="Waktu awal tampilan, detik")
    parser.add_argument("--no-gui", action="store_true", help="Simpan hasil dan preview tanpa jendela")
    parser.add_argument("--preview", type=Path, help="Simpan tampilan pada --time ke PNG tanpa jendela")
    args = parser.parse_args()
    if not np.isfinite(args.time):
        parser.error("--time harus berupa angka terbatas.")
    if args.no_gui or args.preview:
        matplotlib.use("Agg")
    from eeg_motor_view import make_view, play, diagnostic_plots
    import matplotlib.pyplot as plt

    print("Memproses seluruh run R04/R08/R12; kalibrasi dan pengujian dipisahkan.")
    try:
        analysis = analyze_all(args.data_dir)
        records, trials, stream, summary, filters, models = analysis
        if args.record not in records:
            raise ValueError("--record harus salah satu: " + ", ".join(records))
        save_outputs(args.output_dir, analysis)
        write_report(args.output_dir, summary, filters)
        diagnostic_plots(args.output_dir, summary, filters)
    except (OSError, ValueError, KeyError) as error:
        parser.error(str(error))
    three = summary["trial_three_class"]
    two = summary["trial_two_class_task_only"]
    moving = summary["stream_three_class"]
    print(f"Data: {summary['records']} run, {summary['samples']:,} sampel waktu, 64 kanal.")
    print(f"Trial 3 kelas: {three['correct']}/{three['n']} = {three['accuracy']:.2%}.")
    print(f"Pembanding selalu rest: {three['majority_baseline_accuracy']:.2%}.")
    print(f"Trial kiri/kanan saja: {two['correct']}/{two['n']} = {two['accuracy']:.2%}.")
    print(f"Jendela berjalan 3 kelas: {moving['accuracy']:.2%} "
          "(jendela bertumpang tindih, bukan trial independen).")
    print("Skeleton memakai prediksi 3 kelas; sudut jari adalah pose ilustrasi.")
    print("Hasil dan penjelasan:", args.output_dir.resolve())
    record = records[args.record]
    t = record["data"]["t"]
    start = float(np.clip(args.time, t[0], t[-1]))
    fig, draw_at = make_view(args.record, record, summary)
    draw_at(start)
    if args.no_gui or args.preview:
        preview = args.preview or args.output_dir / f"{args.record}_preview.png"
        preview.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(preview, dpi=150)
        plt.close(fig)
        print("Preview:", preview.resolve())
    else:
        play(fig, draw_at, t, start)
        plt.show()


if __name__ == "__main__":
    main()
