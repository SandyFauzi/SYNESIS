# Program pemetaan EEG untuk proyek UTS

Jalankan di folder Tugas_EEG:

    python UTS_EEG_Pemetaan_Tangan.py

Jika pustaka belum tersedia:

    python -m pip install numpy scipy pandas matplotlib

Program selalu menganalisis seluruh CSV EEG R04/R08/R12 di CSV_EEG.
Jendela menampilkan satu rekaman; pilih lewat --record:

    python UTS_EEG_Pemetaan_Tangan.py --record S002R08 --time 7

Simpan hasil tanpa membuka jendela:

    python UTS_EEG_Pemetaan_Tangan.py --no-gui --time 7

Simpan PNG tertentu:

    python UTS_EEG_Pemetaan_Tangan.py --record S001R04 --time 7 --preview tampilan.png

Kontrol: tombol Jeda/Putar, slider waktu, spasi, panah kiri/kanan, R untuk awal.
Analisis awal memerlukan sekitar 20 detik pada komputer ini. Setelah analisis,
animasi mengikuti waktu rekaman. Gerakan adalah pergantian pose kelas hasil prediksi.

## Tiga berkas program

- UTS_EEG_Pemetaan_Tangan.py: titik masuk dan pilihan perintah.
- eeg_motor_analysis.py: filter, fitur, kalibrasi, evaluasi, dan ekspor.
- eeg_motor_view.py: dua skeleton, grafik EEG, fitur, timeline, kontrol, dan grafik evaluasi.

Simpan ketiganya bersama. Program ini tidak bergantung pada program skeleton
sebelumnya. Data masukan tetap CSV_EEG beserta pasangan *_annotations.csv.

## Alur yang bisa kamu jelaskan saat UTS

1. Masukan adalah 64 deret amplitudo EEG dalam mikrovolt, pada 160 sampel/detik.
   C3 dan C4 adalah nama posisi elektroda di kepala, bukan sensor di tangan.
2. Pada setiap sampel, kurangi rata-rata 64 kanal dari masing-masing kanal
   (common average reference).
3. Jalankan dua filter digital kausal: mu 8–13 Hz dan beta 13–30 Hz.
   Transformasi-Z dipakai untuk menyatakan H(z), menganalisis pole,
   dan menurunkan persamaan beda. Semua kanal difilter; C3/C4 dipakai untuk fitur.
4. Hitung daya tiap pita/kanal, lalu bandingkan dengan daya rest awal:
   fitur = 10 log10(P/P0). Ini menghasilkan empat angka dalam dB.
5. LDA yang dikalibrasi memakai dua run lain dari subjek yang sama
   menentukan perkiraan rest, imajinasi kiri, atau imajinasi kanan.
   Ini tahap klasifikasi statistik terawasi yang terpisah dari T-Z.
6. Skeleton mengikuti kelas PREDIKSI. Anotasi hanya dipakai untuk kalibrasi
   di run lain dan untuk menilai hasil; anotasi run uji tidak memilih pose.

Bagian yang paling langsung terkait T-Z ada pada manual_sos() dan preprocess()
di eeg_motor_analysis.py. Untuk tahap klasifikasi, baca fit_lda() dan
continuous_prediction(). Ini lebih lengkap daripada demo rata-rata tiga sampel,
tetapi kamu bisa mempelajarinya bertahap dengan enam langkah di atas.

Program tidak menghitung X(z) di semua titik z untuk menggambar tangan.
Hubungannya Y(z)=H(z)X(z); H(z) diwujudkan sebagai filter melalui persamaan beda.
Setelah filter, daya dan LDA adalah tahap berikutnya.

## Cara membaca jendela

- Tangan berwarna: kelas yang diperkirakan aktif. Tangan abu-abu: pose netral.
- Prediksi dan instruksi ditulis terpisah; teks merah bila berbeda.
- Grafik batang: perubahan daya terhadap rest awal, bukan sudut jari.
- Timeline dua baris: instruksi eksperimen dan prediksi sepanjang rekaman.
- Grafik amplitudo: C3 setelah referensi, kemudian hasil mu dan beta.
- Semua perhitungan prediksi memakai sampel sampai waktu keputusan.
  Grafik di jendela dapat memperlihatkan bagian rekaman sesudah kursor
  sebagai konteks tampilan; bagian itu tidak dipakai dalam keputusan tersebut.

Data merupakan rekaman imajinasi tangan, bukan pelacakan posisi tangan/jari.
Tekukan skeleton adalah pose ilustrasi tetap. Akurasi tiga kelas masih di bawah
pembanding yang selalu menebak rest pada data ini, sehingga belum menjadi
pengendali tangan yang andal. Akurasi model kiri/kanan saja dihitung khusus
interval tugas yang diketahui; jangan menyamakannya dengan akurasi animasi.

Angka hasil lengkap, pembagian kalibrasi/uji, koefisien H(z), dan batas metode:
UTS_EEG_Pemetaan_Hasil/LAPORAN.md. Untuk melihat pengaruh T-Z, buka filter_TZ.png;
untuk melihat kesalahan perkiraan, buka confusion_matrix.png.

Metode tidak menghapus artefak mata/otot secara khusus. Dua subjek belum cukup
untuk menilai kemampuan pada orang baru. Filter kausal per run, tetapi model
offline memakai run lain termasuk yang direkam sesudah run uji. Kalibrasi
sistem langsung harus diselesaikan sebelum penggunaan.

Sumber data:
https://physionet.org/content/eegmmidb/1.0.0/
Pemetaan run:
https://mne.tools/stable/generated/mne.datasets.eegbci.load_data.html
