"""Tampilan prediksi EEG. Pose jari adalah ilustrasi kelas hasil LDA."""
import time
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib.colors import ListedColormap
from matplotlib.widgets import Button, Slider
from scipy import signal

from eeg_motor_analysis import BASELINE, BANDS, FEATURES, NAMES, FS

COLORS = {"T0": "#A6AFBB", "T1": "#2874A6", "T2": "#D46B29", "": "#EFF1F4"}
FPS = 20

# Satu pergelangan + 5 jari x 4 titik = 21 titik kerangka.
# Titik adalah gambar 2D buatan untuk ilustrasi, bukan hasil pengukuran.
OPEN_HAND = np.array([
    [0, 0],
    [-.30, .42], [-.70, .72], [-1.04, 1.03], [-1.30, 1.30],
    [-.45, 1.10], [-.50, 1.85], [-.54, 2.45], [-.56, 2.85],
    [0, 1.20], [0, 2.05], [0, 2.70], [0, 3.10],
    [.45, 1.13], [.52, 1.86], [.57, 2.43], [.60, 2.82],
    [.83, .98], [1, 1.55], [1.12, 2.03], [1.20, 2.35],
], dtype=float)
CLOSED_HAND = np.array([
    [0, 0],
    [-.30, .42], [-.62, .78], [-.45, 1.15], [.16, 1.05],
    [-.45, 1.10], [-.60, 1.53], [-.64, 1.10], [-.45, .88],
    [0, 1.20], [0, 1.70], [0, 1.16], [.03, .89],
    [.45, 1.13], [.57, 1.59], [.60, 1.10], [.46, .87],
    [.83, .98], [1.02, 1.29], [1.06, .94], [.85, .77],
], dtype=float)
BONES = []
for base in [1, 5, 9, 13, 17]:
    BONES.extend([(0, base), (base, base+1), (base+1, base+2), (base+2, base+3)])
BONES.extend([(1, 5), (5, 9), (9, 13), (13, 17)])


def hand_points(bend, mirror=1):
    """bend 0 = terbuka; bend 1 = menekuk penuh secara ilustratif."""
    points = (1-bend) * OPEN_HAND + bend * CLOSED_HAND
    points[:, 0] *= mirror
    return points




def make_view(name, record, summary):
    data, events, predictions = record["data"], record["events"], record["stream"]
    t = data["t"]
    ends = predictions["end_s"].to_numpy()
    predicted = predictions["predicted_label"].to_numpy()
    features = predictions[FEATURES].to_numpy(dtype=float)
    truth_names = {"": "Tanpa anotasi", **NAMES}
    fig = plt.figure(figsize=(13.2, 9))
    fig.suptitle("EEG → filter T-Z → daya mu/beta → perkiraan tangan", fontsize=17, y=.98)
    calibration = predictions["training_records"].iloc[0].replace(",", ", ")
    fig.text(.5, .936, f"Uji: {name}   |   Kalibrasi kelas: {calibration}   |   64 kanal, 160 Hz",
             ha="center", fontsize=10)
    fig.text(.5, .910,
             r"$H(z)=\prod_k\frac{b_{0k}+b_{1k}z^{-1}+b_{2k}z^{-2}}{1+a_{1k}z^{-1}+a_{2k}z^{-2}}$"
             "    |    Mu 8–13 Hz; beta 13–30 Hz; filter kausal",
             ha="center", fontsize=10)
    status = fig.text(.5, .866, "", ha="center", fontsize=11, weight="bold")
    grid = fig.add_gridspec(3, 3, height_ratios=[2.7, 1.3, .6], left=.08,
                           right=.96, bottom=.24, top=.80, hspace=.55, wspace=.5)
    hand_axes = [fig.add_subplot(grid[0, i]) for i in range(2)]
    hand_artists = []
    for ax in hand_axes:
        ax.set(xlim=(-1.6, 1.6), ylim=(-.25, 3.35), aspect="equal")
        ax.axis("off")
        bones, = ax.plot([], [], linewidth=2.7)
        joints = ax.scatter([], [], s=28, zorder=3)
        hand_artists.append((bones, joints))
    feature_ax = fig.add_subplot(grid[0, 2])
    feature_bars = feature_ax.barh(
        np.arange(4), np.zeros(4), color=["#2874A6", "#D46B29"]*2)
    feature_ax.set_yticks(np.arange(4), ["Mu C3", "Mu C4", "Beta C3", "Beta C4"])
    feature_ax.invert_yaxis()
    feature_ax.axvline(0, color="#777777", linewidth=1)
    feature_ax.set(xlim=(-15, 15), xlabel="10 log10(P/P0) [dB]", title="Daya relatif rest awal")
    feature_ax.grid(axis="x", alpha=.2)
    feature_text = feature_ax.text(.5, -.30, "", transform=feature_ax.transAxes,
                                   ha="center", fontsize=9)
    eeg_ax = fig.add_subplot(grid[1, :])
    raw_line, = eeg_ax.plot([], [], color="#B7BEC6", linewidth=.7, label="C3 setelah referensi")
    mu_line, = eeg_ax.plot([], [], color="#2874A6", linewidth=1, label="C3 mu")
    beta_line, = eeg_ax.plot([], [], color="#46936A", linewidth=.8, label="C3 beta")
    eeg_cursor = eeg_ax.axvline(0, color="#D46B29", linewidth=1.3)
    eeg_ax.set(xlabel="Waktu (s)", ylabel="EEG (uV)")
    eeg_ax.grid(alpha=.2)
    eeg_ax.legend(loc="upper right", fontsize=8, ncols=3)
    timeline_ax = fig.add_subplot(grid[2, :])
    display_t = np.arange(0, len(t)/FS, .25)
    reference_codes = np.zeros(len(display_t), dtype=int)
    for event in events.itertuples(index=False):
        selected = (display_t >= event.onset_s) & (display_t < event.end_s)
        reference_codes[selected] = {"T0": 1, "T1": 2, "T2": 3}[event.label]
    indices = np.searchsorted(ends, display_t, side="right") - 1
    pred_codes = np.zeros(len(display_t), dtype=int)
    valid = indices >= 0
    pred_codes[valid] = [{"T0": 1, "T1": 2, "T2": 3}[c] for c in predicted[indices[valid]]]
    timeline_ax.imshow(np.vstack([reference_codes, pred_codes]), aspect="auto",
                       interpolation="nearest", vmin=0, vmax=3,
                       cmap=ListedColormap([COLORS[c] for c in ["", "T0", "T1", "T2"]]),
                       extent=(0, len(t)/FS, 1.5, -.5))
    timeline_ax.set(yticks=[0, 1], yticklabels=["Instruksi", "Prediksi"], xlabel="Seluruh rekaman (s)")
    timeline_cursor = timeline_ax.axvline(0, color="#222222", linewidth=1.3)
    tri = summary["trial_three_class"]
    fig.text(.08, .174,
             f"Uji antarrekaman, 3 kelas: {tri['accuracy']:.1%} | "
             f"Pembanding selalu rest: {tri['majority_baseline_accuracy']:.1%} | "
             "Abu: rest; biru: kiri; oranye: kanan.", fontsize=9)
    fig.text(.08, .054,
             "Spasi: jeda/putar. Panah: geser 1 detik. R: awal. "
             "Keputusan memakai 2,5 s sebelumnya; diperbarui tiap 0,25 s.", fontsize=9)
    fig.text(.08, .025,
             "Skeleton mengikuti PREDIKSI. Tekukan adalah pose ilustrasi tetap; "
             "data tidak berisi koordinat atau sudut jari.", fontsize=9)

    def draw_at(seconds):
        seconds = float(np.clip(seconds, t[0], t[-1]))
        index = int(np.searchsorted(ends, seconds, side="right") - 1)
        active = events[(events["onset_s"] <= seconds) & (events["end_s"] > seconds)]
        truth = str(active.iloc[0]["label"]) if len(active) else ""
        label = str(predicted[index]) if index >= 0 else ""
        if index < 0:
            description = f"{seconds:.2f} s | Kalibrasi rest awal sampai {BASELINE[1]:.1f} s"
            value = np.zeros(4)
        else:
            match = "sesuai instruksi" if label == truth else "berbeda dari instruksi"
            description = (f"{seconds:.2f} s | Prediksi: {NAMES[label]} | "
                           f"Instruksi: {truth_names[truth]} ({match})")
            value = features[index]
        status.set_text(description)
        status.set_color("#333333" if label == truth or index < 0 else "#AE442D")
        # Hanya LABEL PREDIKSI yang dipakai untuk pose tangan.
        for j, target in enumerate(["T1", "T2"]):
            is_active = label == target
            bend = .85 if is_active else .12
            points = hand_points(bend, -1 if j == 0 else 1)
            segments = np.array([[points[a], points[b], [np.nan, np.nan]]
                                 for a, b in BONES]).reshape(-1, 2)
            bones, joints = hand_artists[j]
            color = COLORS[target] if is_active else COLORS["T0"]
            bones.set_data(segments[:, 0], segments[:, 1])
            bones.set_color(color)
            joints.set_offsets(points)
            joints.set_color(color)
            hand_axes[j].set_title(
                ("Tangan kiri" if j == 0 else "Tangan kanan")
                + ("\nDiperkirakan aktif" if is_active else "\nPose netral"),
                fontsize=12, color=color, pad=6)
        for bar, width in zip(feature_bars, value):
            bar.set_width(width)
        limit = max(15, float(np.max(np.abs(value)))+2)
        feature_ax.set_xlim(-limit, limit)
        feature_text.set_text("Negatif: daya turun terhadap rest.\nPositif: daya naik terhadap rest.")
        start = max(0, min(seconds-4, float(t[-1])-8))
        end = min(float(t[-1]), start+8)
        selected = (t >= start) & (t <= end)
        raw_line.set_data(t[selected], data["car"][selected, 0])
        mu_line.set_data(t[selected], data["filtered"]["mu"][selected, 0])
        beta_line.set_data(t[selected], data["filtered"]["beta"][selected, 0])
        amplitude = max(10, float(np.max(np.abs(data["car"][selected, 0]))) * 1.05)
        eeg_ax.set(xlim=(start, end), ylim=(-amplitude, amplitude))
        eeg_cursor.set_xdata([seconds, seconds])
        timeline_cursor.set_xdata([seconds, seconds])
        return label, truth

    return fig, draw_at


def play(fig, draw_at, t, start):
    """Kontrol animasi. Waktu memakai jam agar sesuai durasi rekaman."""
    state = {'playing': True, 'position': start, 'origin': time.perf_counter()-start}
    button = Button(fig.add_axes([.08, .105, .08, .045]), 'Jeda')
    slider = Slider(fig.add_axes([.24, .11, .65, .03]), 'Waktu',
                    valmin=float(t[0]), valmax=float(t[-1]), valinit=start, valfmt='%.2f s')

    def seek(value):
        state['position'] = float(value)
        state['origin'] = time.perf_counter()-state['position']
        draw_at(state['position'])
        fig.canvas.draw_idle()

    def toggle(event=None):
        state['playing'] = not state['playing']
        state['origin'] = time.perf_counter()-state['position']
        button.label.set_text('Jeda' if state['playing'] else 'Putar')
        fig.canvas.draw_idle()

    def keypress(event):
        if event.key == ' ':
            toggle()
        elif event.key in ['left', 'right', 'r']:
            value = 0 if event.key == 'r' else state['position']+(-1 if event.key == 'left' else 1)
            slider.set_val(float(np.clip(value, t[0], t[-1])))

    def tick(frame):
        if state['playing']:
            state['position'] = min(time.perf_counter()-state['origin'], float(t[-1]))
            if state['position'] >= t[-1]:
                state['playing'] = False
                button.label.set_text('Putar')
            # Pembaruan slider dari animasi tidak memanggil seek lagi.
            slider.eventson = False
            slider.drawon = False
            slider.set_val(state['position'])
            slider.eventson = True
            slider.drawon = True
            draw_at(state['position'])
        return ()

    slider.on_changed(seek)
    button.on_clicked(toggle)
    fig.canvas.mpl_connect('key_press_event', keypress)
    animation = FuncAnimation(fig, tick, interval=1000/FPS, cache_frame_data=False)
    # Simpan referensi agar tombol, slider, dan animasi tetap hidup.
    fig.eeg_controls = (animation, slider, button)
    return animation




def diagnostic_plots(output_dir, summary, filters):
    destination = Path(output_dir)
    fig, axes = plt.subplots(1, 3, figsize=(13, 4.8), constrained_layout=True)
    cases = [
        ("Trial: rest / kiri / kanan", summary["trial_three_class"]),
        ("Trial: kiri / kanan saja", summary["trial_two_class_task_only"]),
        ("Jendela berjalan: 3 kelas", summary["stream_three_class"]),
    ]
    for ax, (name, metric) in zip(axes, cases):
        matrix = np.asarray(metric["confusion_matrix"])
        ax.imshow(matrix, cmap="Blues", vmin=0, vmax=max(1, matrix.max()))
        names = [NAMES[c].replace("Imajinasi ", "") for c in metric["classes"]]
        ax.set(xticks=np.arange(len(names)), yticks=np.arange(len(names)),
               xticklabels=names, yticklabels=names, xlabel="Prediksi", ylabel="Instruksi asli")
        ax.set_title(f"{name}\nAkurasi {metric['accuracy']:.1%}; "
                     f"balanced {metric['balanced_accuracy']:.1%}", fontsize=11)
        for i in range(len(names)):
            for j in range(len(names)):
                ax.text(j, i, str(matrix[i, j]), ha="center", va="center",
                        color="white" if matrix[i, j] > matrix.max()/2 else "#222222")
    fig.suptitle("Pengujian pada run yang tidak dipakai kalibrasi kelas", fontsize=14)
    fig.savefig(destination / "confusion_matrix.png", dpi=150)
    plt.close(fig)

    fig, (response_ax, pole_ax) = plt.subplots(1, 2, figsize=(11, 4.8), constrained_layout=True)
    angle = np.linspace(0, 2*np.pi, 400)
    pole_ax.plot(np.cos(angle), np.sin(angle), "--", color="#9AA4AF", label="Lingkaran |z|=1")
    for name, sos in filters.items():
        frequency, response = signal.sosfreqz(sos, worN=2048, fs=FS)
        color = "#2874A6" if name == "mu" else "#D46B29"
        response_ax.plot(frequency, 20*np.log10(np.maximum(abs(response), 1e-9)),
                         label=f"{name}: {BANDS[name][0]}–{BANDS[name][1]} Hz", color=color)
        _, poles, _ = signal.sos2zpk(sos)
        pole_ax.scatter(poles.real, poles.imag, marker="x", s=60, color=color, label=f"Pole {name}")
    response_ax.set(xlim=(0, 40), ylim=(-70, 3), xlabel="Frekuensi (Hz)",
                    ylabel="Gain (dB)", title="Pita yang dilewatkan H(z)")
    response_ax.axhline(-3.01, color="#777777", linestyle=":", linewidth=1)
    response_ax.grid(alpha=.2)
    response_ax.legend(fontsize=9)
    pole_ax.set(xlim=(-1.1, 1.1), ylim=(-1.1, 1.1), xlabel="Real(z)", ylabel="Imag(z)",
               aspect="equal", title="Pole di dalam lingkaran: filter kausal stabil")
    pole_ax.grid(alpha=.2)
    pole_ax.legend(fontsize=9, loc="lower left")
    fig.suptitle("Transformasi-Z untuk desain dan analisis filter EEG", fontsize=14)
    fig.savefig(destination / "filter_TZ.png", dpi=150)
    plt.close(fig)
