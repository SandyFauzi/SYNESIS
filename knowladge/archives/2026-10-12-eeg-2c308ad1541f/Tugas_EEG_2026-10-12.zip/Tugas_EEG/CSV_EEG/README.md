# Data EEG dalam CSV

Sumber: PhysioNet EEG Motor Movement/Imagery Dataset versi 1.0.0.
https://physionet.org/content/eegmmidb/1.0.0/
Schalk, G. (2009). DOI: https://doi.org/10.13026/C28G6P

Data terdiri dari subjek S001 dan S002, masing-masing run R04, R08, R12.
Ketiga run menggunakan tugas imajinasi gerakan tangan kiri/kanan:
https://mne.tools/stable/generated/mne.datasets.eegbci.load_data.html
Dua rekaman awal dipertahankan dan empat rekaman tambahan diunduh dari PhysioNet.
Semua enam EDF cocok dengan SHA-256 resmi dalam PhysioNet_SHA256SUMS.txt.

Total: 119040 baris sampel EEG dan 90 trial T1/T2.

Setiap CSV sinyal berisi time_s (detik sejak awal rekaman), annotation (T0/T1/T2), dan 64 kanal EEG dalam mikrovolt (uV).
Satu baris adalah satu waktu pengambilan sampel. Frekuensi sampling 160 Hz, sehingga jarak waktu antarbaris 0.00625 detik.
Sinyal dipertahankan tanpa filter, penghalusan, interpolasi, atau penghilangan artefak.
Kalibrasi digital-ke-fisik mengikuti physical/digital min/max pada header EDF. metadata.json menyimpan parameter dan nama kanal asli.
Titik di akhir nama kanal EDF dihapus untuk header CSV: C3.. menjadi C3_uV.

Setiap *_annotations.csv menyimpan indeks anotasi (mulai 0), onset, durasi, waktu akhir, label, dan nama aktivitas.
T0 = istirahat; T1 = imajinasi tangan kiri; T2 = imajinasi tangan kanan. Pemetaan ini khusus run R04/R08/R12.
Interval anotasi memakai onset inklusif dan akhir eksklusif. annotation kosong berarti waktu tersebut tidak memiliki anotasi EDF; tidak otomatis diberi T0.
manifest.csv memuat ringkasan, URL asal, checksum, dan nama CSV setiap rekaman.
CSV menggunakan koma sebagai pemisah dan titik sebagai tanda desimal. Di Excel, gunakan Data > From Text/CSV bila kolom tidak terpisah otomatis.

Notebook lama masih menetapkan dua file awal di EDF_FILES. Untuk menggunakan keenam rekaman, ganti baris tersebut menjadi:
EDF_FILES = sorted(DATA_DIR.glob("S00[12]R[0-9][0-9].edf"))
Folder ini hanya menambahkan run R04/R08/R12. Jika nanti menambahkan jenis run lain, sesuaikan pemetaan label terlebih dahulu.
Ringkasan notebook lama menggabungkan trial; bila membandingkan subjek, pertahankan identitas subjek dalam analisis.
