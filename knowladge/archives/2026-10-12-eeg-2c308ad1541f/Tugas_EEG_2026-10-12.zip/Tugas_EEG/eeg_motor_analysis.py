"""Pemrosesan EEG, kalibrasi LDA, dan evaluasi antarrekaman.

T-Z dipakai untuk mendeskripsikan filter IIR; LDA adalah tahap
klasifikasi terpisah. Label rekaman uji tidak masuk ke prediksi.
"""
from dataclasses import dataclass
from pathlib import Path
import hashlib
import json
import re

import numpy as np
import pandas as pd
from scipy import signal

FS = 160
BANDS = {"mu": (8, 13), "beta": (13, 30)}
FEATURES = ["mu_C3_dB", "mu_C4_dB", "beta_C3_dB", "beta_C4_dB"]
CLASSES = ["T0", "T1", "T2"]
NAMES = {"T0": "Istirahat", "T1": "Imajinasi kiri", "T2": "Imajinasi kanan"}
BASELINE = (1.0, 3.5)       # Rest awal; detik pertama mengandung transien filter.
TRIAL_WINDOW = (1.0, 3.5)   # Relatif terhadap onset instruksi.
STREAM_WINDOW = 2.5
STREAM_STEP = .25
SHRINKAGE = .5               # Tetap; tidak dipilih dari hasil rekaman uji.


def manual_sos(sos, x):
    """Persamaan beda tiap bagian H(z), kondisi awal semuanya nol.

    y[n] = b0*x[n]+b1*x[n-1]+b2*x[n-2]-a1*y[n-1]-a2*y[n-2]
    a0 = 1. Keluaran bagian pertama menjadi masukan bagian kedua.
    """
    output = np.asarray(x, dtype=float).copy()
    for section in sos:
        b0, b1, b2, a0, a1, a2 = section / section[3]
        y = np.zeros_like(output)
        for n in range(len(output)):
            y[n] = b0 * output[n]
            if n >= 1:
                y[n] += b1 * output[n-1] - a1 * y[n-1]
            if n >= 2:
                y[n] += b2 * output[n-2] - a2 * y[n-2]
        output = y
    return output


def load_record(csv_path):
    if not re.fullmatch(r"S\d{3}R(?:04|08|12)", csv_path.stem):
        raise ValueError(f"{csv_path.name}: hanya run imajinasi R04/R08/R12.")
    frame = pd.read_csv(csv_path)
    channels = [c for c in frame if c.endswith("_uV")]
    if len(channels) != 64 or not {"C3_uV", "C4_uV"} <= set(channels):
        raise ValueError(f"{csv_path.name}: perlu 64 kanal EEG termasuk C3/C4.")
    t = frame["time_s"].to_numpy(dtype=float)
    eeg = frame[channels].to_numpy(dtype=float)
    if len(t) < 640 or not np.isfinite(t).all() or not np.isfinite(eeg).all():
        raise ValueError(f"{csv_path.name}: data tidak lengkap atau tidak terbatas.")
    if abs(t[0]) > 1e-9 or not np.allclose(np.diff(t), 1/FS, atol=1e-8, rtol=0):
        raise ValueError(f"{csv_path.name}: waktu harus mulai 0 dengan fs=160 Hz.")
    events = pd.read_csv(csv_path.with_name(csv_path.stem + "_annotations.csv"))
    if not {"onset_s", "duration_s", "end_s", "label"} <= set(events):
        raise ValueError("Kolom anotasi tidak lengkap.")
    if not events["label"].isin(CLASSES).all():
        raise ValueError("Anotasi harus T0/T1/T2.")
    times = events[["onset_s", "duration_s", "end_s"]].to_numpy(dtype=float)
    if (not np.isfinite(times).all() or (times[:, 1] <= 0).any()
            or not np.allclose(times[:, 0] + times[:, 1], times[:, 2])
            or (times[1:, 0] < times[:-1, 2] - 1e-8).any()
            or times[0, 0] < 0 or times[-1, 2] > len(t)/FS + 1e-8):
        raise ValueError("Interval anotasi tidak valid.")
    first = events.iloc[0]
    if first["label"] != "T0" or first["onset_s"] != 0 or first["end_s"] < BASELINE[1]:
        raise ValueError("Diperlukan instruksi rest pada 0–3,5 s untuk kalibrasi.")
    return t, eeg, channels, events


def preprocess(t, eeg, channels, filters):
    """Tidak menerima anotasi. Seluruh 64 kanal direferensi dan difilter."""
    car = eeg - eeg.mean(axis=1, keepdims=True)
    central = [channels.index("C3_uV"), channels.index("C4_uV")]
    filtered = {}
    maximum_error = 0.0
    for name, sos in filters.items():
        all_channels = signal.sosfilt(sos, car, axis=0)  # Kausal; tanpa filtfilt.
        # Cocokkan implementasi manual T-Z pada 10 detik pertama, semua kanal.
        manual = manual_sos(sos, car[:1600])
        error = float(np.max(np.abs(manual - all_channels[:1600])))
        maximum_error = max(maximum_error, error)
        if not np.allclose(manual, all_channels[:1600], atol=1e-9, rtol=1e-9):
            raise ValueError("Persamaan beda manual tidak cocok dengan sosfilt.")
        filtered[name] = all_channels[:, central]
    squared = np.column_stack([filtered[name] ** 2 for name in BANDS])
    selected = (t >= BASELINE[0]) & (t < BASELINE[1])
    baseline_power = squared[selected].mean(axis=0)
    if (baseline_power <= 1e-12).any():
        raise ValueError("Daya baseline terlalu kecil.")
    return {
        "t": t, "raw": eeg[:, central], "car": car[:, central],
        "filtered": filtered, "squared": squared,
        "baseline_power": baseline_power, "manual_error_uV": maximum_error,
    }


def power_feature(processed, start, end):
    """Fitur = 10 log10(P/P0); power dalam uV^2, fitur dalam dB."""
    t = processed["t"]
    i = int(np.searchsorted(t, start, side="left"))
    j = int(np.searchsorted(t, end, side="left"))
    if j <= i:
        raise ValueError("Jendela daya kosong.")
    power = processed["squared"][i:j].mean(axis=0)
    return 10 * np.log10(np.maximum(power, 1e-12) / processed["baseline_power"])


def trial_features(processed, events, record):
    rows = []
    for event in events.itertuples(index=False):
        if event.duration_s < TRIAL_WINDOW[1]:
            raise ValueError(f"{record}: trial terlalu singkat.")
        start = float(event.onset_s + TRIAL_WINDOW[0])
        end = float(event.onset_s + TRIAL_WINDOW[1])
        feature = power_feature(processed, start, end)
        rows.append({
            "record": record, "subject": record[:4],
            "event_index": int(event.event_index),
            "evaluation_eligible": int(event.event_index) != 0,
            "onset_s": float(event.onset_s), "feature_start_s": start,
            "feature_end_s": end, "true_label": event.label,
            **dict(zip(FEATURES, feature)),
        })
    return pd.DataFrame(rows)


@dataclass
class LinearModel:
    """LDA regularisasi: skor linear dari pola daya saat kalibrasi."""
    classes: list
    weights: np.ndarray
    intercept: np.ndarray

    def scores(self, features):
        return np.atleast_2d(features) @ self.weights.T + self.intercept

    def predict(self, features):
        return np.asarray(self.classes)[self.scores(features).argmax(axis=1)]

    def as_dict(self):
        return {"classes": self.classes, "features": FEATURES,
                "weights": self.weights.tolist(), "intercept": self.intercept.tolist()}


def fit_lda(frame, classes):
    x = frame[FEATURES].to_numpy(dtype=float)
    y = frame["true_label"].to_numpy()
    if any(np.count_nonzero(y == c) < 2 for c in classes):
        raise ValueError("Tiap kelas kalibrasi perlu minimal dua trial.")
    means = np.array([x[y == c].mean(axis=0) for c in classes])
    residual = np.vstack([x[y == c] - means[i] for i, c in enumerate(classes)])
    covariance = residual.T @ residual / (len(residual) - len(classes))
    covariance = ((1-SHRINKAGE) * covariance
                  + SHRINKAGE * np.diag(np.diag(covariance)))
    covariance += np.eye(len(FEATURES)) * max(float(np.trace(covariance)), 1.0) * 1e-6
    weights = np.linalg.solve(covariance, means.T).T
    intercept = -.5 * np.sum(means * weights, axis=1)  # Prior tiap kelas sama.
    return LinearModel(list(classes), weights, intercept)


def continuous_prediction(processed, model):
    """Jendela bergerak ke belakang; tidak ada label atau sampel masa depan.

    end_s adalah saat keputusan tersedia. Interval input [start_s, end_s).
    Baseline lengkap pada 3,5 s; langkah berikutnya setiap 0,25 s.
    """
    rows = []
    duration = len(processed["t"]) / FS
    for end in np.arange(BASELINE[1], duration + 1e-9, STREAM_STEP):
        start = end - STREAM_WINDOW
        feature = power_feature(processed, start, end)
        scores = model.scores(feature)[0]
        prediction = model.classes[int(np.argmax(scores))]
        # Skor dibandingkan ke kelas terbaik; bukan probabilitas/akurasi.
        scores = scores - scores.max()
        rows.append({
            "start_s": float(start), "end_s": float(end),
            "predicted_label": prediction,
            **dict(zip(FEATURES, feature)),
            **{f"score_{c}_relative": float(s) for c, s in zip(model.classes, scores)},
        })
    return pd.DataFrame(rows)


def add_reference(predictions, events):
    """Anotasi baru dibaca SESUDAH prediksi, untuk pembandingan/evaluasi."""
    result = predictions.copy()
    truth, eligible = [], []
    for row in result.itertuples(index=False):
        # Status instruksi pada end_s; bukan input classifier.
        active = events[(events["onset_s"] <= row.end_s)
                        & (events["end_s"] > row.end_s)]
        truth.append(str(active.iloc[0]["label"]) if len(active) else "")
        # Skor hanya jendela yang seluruhnya di dalam satu interval.
        same = events.iloc[1:]
        same = same[(same["onset_s"] <= row.start_s + 1e-9)
                    & (same["end_s"] >= row.end_s - 1e-9)]
        eligible.append(str(same.iloc[0]["label"]) if len(same) else "")
    result["reference_at_end"] = truth
    result["evaluation_label"] = eligible
    result["evaluation_eligible"] = result["evaluation_label"].isin(CLASSES)
    result["correct_for_evaluation"] = pd.array(
        [p == y if y else pd.NA for p, y in
         zip(result["predicted_label"], result["evaluation_label"])], dtype="boolean")
    return result


def metrics(truth, prediction, classes):
    truth, prediction = np.asarray(truth), np.asarray(prediction)
    matrix = np.array([[np.sum((truth == a) & (prediction == b)) for b in classes]
                       for a in classes], dtype=int)
    counts = matrix.sum(axis=1)
    recalls = np.divide(matrix.diagonal(), counts,
                        out=np.zeros(len(classes), dtype=float), where=counts > 0)
    total = int(matrix.sum())
    return {
        "classes": list(classes), "n": total,
        "correct": int(matrix.diagonal().sum()),
        "accuracy": float(matrix.diagonal().sum()/total) if total else None,
        "balanced_accuracy": float(recalls[counts > 0].mean()) if total else None,
        "recall_by_class": dict(zip(classes, recalls.tolist())),
        "confusion_matrix": matrix.tolist(),
        "majority_baseline_accuracy": float(counts.max()/total) if total else None,
    }


def analyze_all(data_dir):
    files = sorted(p for p in Path(data_dir).glob("*.csv")
                   if re.fullmatch(r"S\d{3}R(?:04|08|12)", p.stem))
    if not files:
        raise ValueError("Tidak ada CSV EEG run R04/R08/R12.")
    filters = {name: signal.butter(2, band, btype="bandpass", fs=FS, output="sos")
               for name, band in BANDS.items()}
    records, frames = {}, []
    for path in files:
        t, eeg, channels, events = load_record(path)
        processed = preprocess(t, eeg, channels, filters)
        trials = trial_features(processed, events, path.stem)
        records[path.stem] = {"data": processed, "events": events, "trials": trials}
        frames.append(trials)
    all_trials = pd.concat(frames, ignore_index=True)
    trial_results, streams, folds = [], [], []
    models = {}
    for name, record in records.items():
        # Kalibrasi hanya run LAIN dari subjek yang sama, tanpa run uji.
        training = all_trials[(all_trials["subject"] == name[:4])
                              & (all_trials["record"] != name)
                              & all_trials["evaluation_eligible"]]
        training_records = sorted(training["record"].unique().tolist())
        if len(training_records) < 2:
            raise ValueError(f"{name}: perlu minimal dua run lain milik subjek ini.")
        model3 = fit_lda(training, CLASSES)
        hand_training = training[training["true_label"].isin(["T1", "T2"])]
        model2 = fit_lda(hand_training, ["T1", "T2"])
        held = record["trials"].copy()
        held["training_records"] = ",".join(training_records)
        held["predicted_3class"] = model3.predict(held[FEATURES])
        held["correct_3class"] = held["predicted_3class"] == held["true_label"]
        eligible = held["evaluation_eligible"]
        hand_mask = held["true_label"].isin(["T1", "T2"])
        held["predicted_2class"] = ""
        held.loc[hand_mask, "predicted_2class"] = model2.predict(held.loc[hand_mask, FEATURES])
        stream = add_reference(continuous_prediction(record["data"], model3),
                               record["events"])
        stream.insert(0, "record", name)
        stream.insert(1, "training_records", ",".join(training_records))
        record["stream"] = stream
        models[name] = {"training_records": training_records,
                        "baseline_power_uV2": record["data"]["baseline_power"].tolist(),
                        "baseline_times_s": BASELINE,
                        "three_class": model3.as_dict(), "two_class": model2.as_dict()}
        folds.append({
            "test_record": name, "training_records": training_records,
            "three_class": metrics(held.loc[eligible, "true_label"],
                                   held.loc[eligible, "predicted_3class"], CLASSES),
            "two_class_task_only": metrics(held.loc[hand_mask, "true_label"],
                                          held.loc[hand_mask, "predicted_2class"], ["T1", "T2"]),
        })
        trial_results.append(held)
        streams.append(stream)
    trials = pd.concat(trial_results, ignore_index=True)
    stream = pd.concat(streams, ignore_index=True)
    hand = trials["true_label"].isin(["T1", "T2"])
    good = stream["evaluation_eligible"]
    eligible = trials["evaluation_eligible"]
    summary = {
        "protocol": "Leave-one-run-out, subject-specific; zero random window splitting",
        "trial_window_s_after_onset": TRIAL_WINDOW,
        "initial_rest_baseline_s": BASELINE,
        "stream_window_s": STREAM_WINDOW, "stream_step_s": STREAM_STEP,
        "lda_covariance_shrinkage": SHRINKAGE, "equal_class_priors": True,
        "records": len(records), "subjects": sorted({n[:4] for n in records}),
        "samples": sum(len(r["data"]["t"]) for r in records.values()),
        "eeg_channels_used": 64, "classifier_channels": ["C3", "C4"],
        "trial_three_class": metrics(trials.loc[eligible, "true_label"],
                                     trials.loc[eligible, "predicted_3class"], CLASSES),
        "trial_total_segments": len(trials),
        "trial_excluded_initial_rest": int((~eligible).sum()),
        "trial_two_class_task_only": metrics(trials.loc[hand, "true_label"],
                                            trials.loc[hand, "predicted_2class"], ["T1", "T2"]),
        "stream_three_class": metrics(stream.loc[good, "evaluation_label"],
                                     stream.loc[good, "predicted_label"], CLASSES),
        "stream_total_windows": len(stream), "stream_excluded_windows": int((~good).sum()),
        "manual_filter_max_error_uV": max(r["data"]["manual_error_uV"] for r in records.values()),
        "folds": folds,
        "limitations": [
            "T0/T1/T2 adalah instruksi eksperimen, bukan gerakan terverifikasi.",
            "Dua subjek; hasil tidak menjamin subjek baru atau perangkat lain.",
            "Skeleton memakai pose buatan; tidak mengukur sudut sendi/jari.",
            "Kausal per run, tetapi kalibrasi offline memakai dua run lain.",
            "Skor LDA relatif bukan probabilitas yang telah dikalibrasi.",
            "Window stream saling tumpang tindih; bukan uji independen.",
            "Rest awal tiap run dipakai baseline dan dikeluarkan dari skor.",
        ],
        "input_csv_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
        "input_annotation_csv_sha256": {
            p.stem + "_annotations.csv": hashlib.sha256(
                p.with_name(p.stem + "_annotations.csv").read_bytes()).hexdigest() for p in files},
    }
    return records, trials, stream, summary, filters, models


def save_outputs(output_dir, analysis):
    records, trials, stream, summary, filters, models = analysis
    destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    trials.to_csv(destination / "trial_dan_prediksi.csv", index=False, float_format="%.10g")
    stream.to_csv(destination / "prediksi_semua_rekaman.csv", index=False, float_format="%.10g")
    for name, record in records.items():
        data = record["data"]
        values = {"time_s": data["t"], "raw_C3_uV": data["raw"][:, 0],
                  "raw_C4_uV": data["raw"][:, 1], "car_C3_uV": data["car"][:, 0],
                  "car_C4_uV": data["car"][:, 1]}
        for band in BANDS:
            for index, channel in enumerate(["C3", "C4"]):
                values[f"{band}_{channel}_uV"] = data["filtered"][band][:, index]
        pd.DataFrame(values).to_csv(destination / f"{name}_sinyal_filter.csv",
                                   index=False, float_format="%.10g")
    filter_info = {}
    for band, sos in filters.items():
        _, poles, _ = signal.sos2zpk(sos)
        filter_info[band] = {
            "passband_Hz": BANDS[band], "sample_rate_Hz": FS, "order": 4,
            "sos_rows_b0_b1_b2_a0_a1_a2": sos.tolist(),
            "max_pole_radius": float(np.abs(poles).max()),
            "H_z": "product((b0+b1*z^-1+b2*z^-2)/(1+a1*z^-1+a2*z^-2))",
        }
    documents = {"evaluasi.json": summary, "filter_TZ.json": filter_info,
                 "model_kalibrasi.json": models}
    for filename, document in documents.items():
        (destination / filename).write_text(
            json.dumps(document, indent=2, ensure_ascii=False, allow_nan=False),
            encoding="utf-8")


def write_report(output_dir, summary, filters):
    """Angka laporan diambil langsung dari evaluasi."""
    three = summary["trial_three_class"]
    two = summary["trial_two_class_task_only"]
    stream = summary["stream_three_class"]
    lines = [
        "# Pemetaan EEG ke perkiraan tangan", "",
        f"Memproses {summary['records']} rekaman, {len(summary['subjects'])} subjek, "
        f"{summary['samples']:,} sampel waktu, dan 64 kanal EEG per sampel.", "",
        "Data R04/R08/R12 merekam **imajinasi gerakan** tangan. T0 berarti istirahat, "
        "T1 instruksi tangan kiri, T2 instruksi tangan kanan. Instruksi bukan bukti "
        "bahwa subjek melakukan gerakan atau membayangkan dengan benar. "
        "Tidak ada koordinat/sudut jari dalam data.", "",
        "## Hasil pengujian", "",
        "| Pengujian | Benar / jumlah | Akurasi | Balanced accuracy | Pembanding mayoritas |",
        "|---|---:|---:|---:|---:|",
    ]
    for label, metric in [
        ("Trial 3 kelas: rest/kiri/kanan", three),
        ("Trial 2 kelas: kiri/kanan, hanya interval tugas", two),
        ("Jendela berjalan 3 kelas", stream),
    ]:
        lines.append(f"| {label} | {metric['correct']}/{metric['n']} | "
                     f"{metric['accuracy']:.2%} | {metric['balanced_accuracy']:.2%} | "
                     f"{metric['majority_baseline_accuracy']:.2%} |")
    lines += [
        "",
        "**Akurasi kiri/kanan dihitung dengan model dua kelas tersendiri ketika "
        "interval tugas sudah diketahui dari eksperimen. Angka itu tidak mengukur "
        "kemampuan mendeteksi istirahat dan bukan akurasi skeleton sepanjang waktu.** "
        "Skeleton memakai model tiga kelas.", "",
        "Model tiga kelas harus dibandingkan dengan tebakan yang selalu memilih "
        "kelas terbanyak (rest). Jika hasil lebih rendah, model belum menunjukkan "
        "manfaat sebagai pengendali. Alur ini berguna untuk belajar pemrosesan "
        "yang dapat diuji, termasuk kegagalannya.", "",
        "Balanced accuracy adalah rata-rata recall tiap kelas sehingga kelas rest "
        "yang lebih banyak tidak mendominasi angka.", "",
        "## Kalibrasi dan pengujian", "",
        "- Untuk setiap run uji, kalibrasi LDA memakai dua run lain dari subjek "
        "yang sama. Tidak ada pembagian acak jendela dari satu run ke train/test.",
        "- Pita, jendela, dan shrinkage ditetapkan; tidak dioptimalkan "
        "menggunakan akurasi run uji.",
        "- Baseline daya memakai instruksi rest awal 1–3,5 s pada masing-masing "
        "run. Sampel 0–1 s tidak masuk baseline karena transien filter.",
        f"- CSV menyimpan {summary['trial_total_segments']} segmen. "
        f"{summary['trial_excluded_initial_rest']} segmen rest awal dipakai "
        "baseline dan dikeluarkan dari penilaian maupun kalibrasi kelas.",
        "- Fitur trial memakai onset+1 sampai onset+3,5 s; ujung interval tidak disertakan.",
        "- Prediksi berjalan memakai 2,5 s sebelumnya, diperbarui setiap 0,25 s. "
        "Prediksi tetap berjalan melewati transisi; skor hanya memakai jendela "
        "yang seluruhnya di dalam satu interval selain rest awal.",
        f"- Dari {summary['stream_total_windows']} jendela, "
        f"{summary['stream_excluded_windows']} dikeluarkan dari skor karena "
        "transisi, baseline, atau area tanpa anotasi. Jendela saling tumpang tindih "
        "sehingga bukan ribuan percobaan independen.",
        "- Pemrosesan sinyal kausal per run. Kalibrasi kelas offline memakai run "
        "lain, yang mungkin direkam sesudah run uji; ini belum pengujian sistem "
        "langsung yang dikalibrasi hanya dari masa lalu.", "",
        "| Run uji | Run kalibrasi | Akurasi 3 kelas | Akurasi kiri/kanan saja |",
        "|---|---|---:|---:|",
    ]
    for fold in summary["folds"]:
        lines.append(f"| {fold['test_record']} | {', '.join(fold['training_records'])} | "
                     f"{fold['three_class']['accuracy']:.2%} | "
                     f"{fold['two_class_task_only']['accuracy']:.2%} |")
    lines += [
        "", "## Letak Transformasi-Z dalam program", "",
        "Alur: amplitudo EEG x[n] → referensi rata-rata 64 kanal → filter IIR "
        "mu/beta y[n] → daya C3/C4 → perubahan daya terhadap rest → LDA → "
        "kelas perkiraan → skeleton ilustratif.", "",
        "Transformasi-Z mendeskripsikan hubungan masukan dan keluaran filter, "
        "Y(z)=H(z)X(z). Program tidak perlu menghitung X(z) untuk semua titik z. "
        "Filter dijalankan lewat persamaan beda, sebagai bentuk praktis H(z).", "",
        "Setiap pita memakai Butterworth orde 4 dari dua bagian orde 2:", "",
        "    H(z) = produk_k (b0_k+b1_k z^-1+b2_k z^-2) / (1+a1_k z^-1+a2_k z^-2)",
        "    y[n] = b0 x[n]+b1 x[n-1]+b2 x[n-2]-a1 y[n-1]-a2 y[n-2]", "",
        "Kondisi awal nol. Keluaran bagian pertama masuk ke bagian kedua. "
        "Pole berada di |z|<1; tidak memakai filtfilt.", "",
    ]
    for band, sos in filters.items():
        lines += [f"**{band}: {BANDS[band][0]}–{BANDS[band][1]} Hz, fs={FS} Hz**", "",
                  "| Bagian | b0 | b1 | b2 | a0 | a1 | a2 |",
                  "|---|---:|---:|---:|---:|---:|---:|"]
        for i, row in enumerate(sos, 1):
            lines.append("| " + str(i) + " | " + " | ".join(f"{v:.9g}" for v in row) + " |")
        lines.append("")
    lines += [
        "Persamaan beda manual dicek terhadap scipy.signal.sosfilt pada 10 s "
        "pertama semua 64 kanal tiap run. Selisih maksimum: "
        f"{summary['manual_filter_max_error_uV']:.3g} uV.", "",
        "P = rata-rata y[n]^2 (uV²). Empat fitur adalah 10 log10(P/P0) dalam dB "
        "untuk mu C3, mu C4, beta C3, beta C4. Negatif menunjukkan penurunan daya "
        "terhadap rest, bukan langsung jumlah tekukan jari.", "",
        "LDA mempelajari pola empat fitur dari trial kalibrasi berlabel, dengan "
        "shrinkage kovarians 0,5 dan prior kelas sama. Ini klasifikasi statistik "
        "terawasi yang terpisah dari T-Z. Skor terbesar memilih kelas; skor relatif "
        "bukan probabilitas yang telah dikalibrasi.", "",
        "## Membaca output", "",
        "- trial_dan_prediksi.csv: fitur, instruksi, run kalibrasi, prediksi tiga "
        "kelas dan dua kelas khusus tugas. evaluation_eligible=False pada rest awal.",
        "- prediksi_semua_rekaman.csv: waktu jendela, fitur, prediksi kausal semua "
        "run; label pembanding ditambahkan sesudah inferensi. end_s adalah waktu "
        "keputusan tersedia. evaluation_label dipakai menghitung skor.",
        "- SxxxRxx_sinyal_filter.csv: C3/C4 asli, setelah referensi, dan hasil "
        "filter. Semua 64 kanal diproses; amplitudo output disimpan untuk C3/C4.",
        "- evaluasi.json: angka penuh, confusion matrix, pembagian run, batas "
        "interpretasi, dan hash input.",
        "- filter_TZ.json dan filter_TZ.png: koefisien H(z), respons frekuensi dan pole.",
        "- model_kalibrasi.json: bobot model per run.",
        "- confusion_matrix.png: baris instruksi, kolom prediksi.", "",
        "Skeleton menekuk tangan yang diperkirakan aktif dengan pose buatan "
        "yang sama setiap kali. Bentuk jari, besar tekukan, dan kecepatan gerak "
        "tidak direkonstruksi dari EEG.", "",
        "## Sumber", "",
        "- [PhysioNet EEG Motor Movement/Imagery Dataset](https://physionet.org/content/eegmmidb/1.0.0/)",
        "- [MNE: pemetaan run](https://mne.tools/stable/generated/mne.datasets.eegbci.load_data.html)",
        "- [SciPy Butterworth](https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.butter.html)",
        "- [SciPy SOS kausal](https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.sosfilt.html)",
        "- [LDA dan shrinkage](https://scikit-learn.org/stable/modules/lda_qda.html)", "",
    ]
    Path(output_dir, "LAPORAN.md").write_text("\n".join(lines), encoding="utf-8")
