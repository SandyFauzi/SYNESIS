# Contoh UTS dasar: jalankan dari folder Tugas_EEG.
# H(z) = (1 + z^-1 + z^-2) / 3
# Kondisi awal: x[-1] = x[-2] = 0.

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Jalankan notebook dari folder Tugas_EEG.
data = pd.read_csv("CSV_EEG/S001R04.csv")
t = data["time_s"].to_numpy()
x = data["C3_uV"].to_numpy(dtype=float)

print("Jumlah sampel:", len(x))
print("Selang waktu antar sampel:", t[1] - t[0], "detik")
print("Lima sampel pertama:")
print(data[["time_s", "C3_uV"]].head().to_string(index=False))

# Tempat menyimpan keluaran filter.
y = np.zeros(len(x))

# Hitung sampel satu per satu sesuai persamaan beda.
for n in range(len(x)):
    sekarang = x[n]
    sebelumnya_1 = x[n - 1] if n >= 1 else 0.0
    sebelumnya_2 = x[n - 2] if n >= 2 else 0.0
    y[n] = (sekarang + sebelumnya_1 + sebelumnya_2) / 3

hasil = pd.DataFrame({
    "time_s": t,
    "EEG_asli_uV": x,
    "EEG_filter_uV": y,
})
print("Hasil untuk lima sampel pertama:")
print(hasil.head().to_string(index=False))

# Tampilkan dua detik pertama.
tampil = t < 2.0
plt.figure(figsize=(11, 4))
plt.plot(t[tampil], x[tampil], label="EEG asli", alpha=0.65, linewidth=0.9)
plt.plot(t[tampil], y[tampil], label="Rata-rata 3 sampel", linewidth=1.2)
plt.xlabel("Waktu (detik)")
plt.ylabel("Amplitudo (uV)")
plt.title("EEG kanal C3 sebelum dan sesudah filter sederhana")
plt.legend()
plt.grid(alpha=0.25)
plt.tight_layout()
plt.savefig("UTS_EEG_hasil_filter.png", dpi=160)
plt.show()

hasil.to_csv("UTS_EEG_hasil_filter.csv", index=False)
print("Tersimpan: UTS_EEG_hasil_filter.csv")
print("Tersimpan: UTS_EEG_hasil_filter.png")
